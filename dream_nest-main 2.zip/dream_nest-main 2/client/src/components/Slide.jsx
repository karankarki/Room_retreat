import "../styles/Slide.scss"

const Slide = () => {
  return (
    <div className="slide">
      <h1>
      Find comfort in every corner with our affordable room rentals. 
      </h1>
    </div>
  );
};

export default Slide;
